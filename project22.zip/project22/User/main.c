#include "stm32f10x.h"                  // Device header
#include "OLED.h"
#include "PWM.h"
#include "Serial.h"
#include "con.h"
#include "Delay.h"
#include "Hall.h"

int main(void){
	
	OLED_Init();
	PWM_Init();
	Hall_Init();
	Serial_Init();
	
	OLED_ShowString(1, 1, "RxData:");


	while(1){
		uint8_t ser_data;
		if(Serial_GetRxFlag() == 1){
			ser_data = Serial_GetRxData();
			OLED_ShowNum(1, 8, ser_data,3);
			
			/*
			switch (ser_data){
			case 'w': PWM_set(100, 100, 100, 100); break;
			case 'a': PWM_set(-100, 100, 100, -100); break;
			case 's': PWM_set(-100, -100, -100, -100); break;
			case 'd': PWM_set(100, -100, -100, 100); break;
			case 'q': PWM_set(-70, 70, -70, 70); break;
			case 'e': PWM_set(70, -70, 70, -70); break;
			
			//case 'i': goon(); break;
			//case 'j': left(); break;
			//case 'k': T_back(); break;
			//case 'l': right(); break;
			
			}

			if (ser_data=='w'||ser_data=='a'||ser_data=='s'||
			ser_data=='d'||ser_data=='q'||ser_data=='e'){
				Delay_ms(250);
				PWM_set(0, 0, 0, 0);
			}
			*/			
			if(ser_data <= 0x80){
				int8_t* mot = PID_change(ser_data);
				PWM_set(mot[0], mot[1], mot[0], mot[1]);
				OLED_ShowNum(2, 1, mot[0], 3);
				OLED_ShowNum(2, 7, mot[1], 3);
			}
			else{
				if(ser_data == 0x81){
					goon();
				}
				else if (ser_data == 0x82){
					left();
				}
				else if (ser_data == 0x83){
					right();
				}
				//else if (ser_data == 0x82){
				//	T_back();
				//}
			}
			
			
			//Serial_SendByte(0x66);
		}
	}
	
	
}
