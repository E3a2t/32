#include "stm32f10x.h"                  // Device header
#include "stdlib.h"

void PWM_Init(void){
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
	TIM_OCInitTypeDef TIM_OCInitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);  //使能TIM1的时钟
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE); //使能 GPIO 的时钟


	//配置GPIO
	//设置该引脚为复用输出功能,输出 TIM1 的 PWM 脉冲波形
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9 |GPIO_Pin_10 |GPIO_Pin_11;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	//初始化TIM1
	TIM_TimeBaseStructure.TIM_Period = 100 - 1;						//设置自动重装载的值
	TIM_TimeBaseStructure.TIM_Prescaler = 36 - 1;					//设置预分频系数
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; //设置向上计数（累加）
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1; //时钟的分频因子，仅对电路的稳定性有影响
	TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStructure);			//初始化TIM1

	//初始化 TIM8 Channel2 PWM 模式
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; // 选择PWM模式1，

	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;	  //设置极性，输出有效电平为：高电平
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; //输出使能
	TIM_OC1Init(TIM1, &TIM_OCInitStructure);					  //初始化外设 TIM OC1 OC2 OC3 OC4
	TIM_OC2Init(TIM1, &TIM_OCInitStructure);
	TIM_OC3Init(TIM1, &TIM_OCInitStructure);
	TIM_OC4Init(TIM1, &TIM_OCInitStructure);
	
	TIM_OC1PreloadConfig(TIM1, TIM_OCPreload_Enable);//使能预装载寄存器
	TIM_OC2PreloadConfig(TIM1, TIM_OCPreload_Enable);
	TIM_OC3PreloadConfig(TIM1, TIM_OCPreload_Enable);
	TIM_OC4PreloadConfig(TIM1, TIM_OCPreload_Enable);

	TIM_Cmd(TIM1, ENABLE); //使能 TIM1

	TIM_CtrlPWMOutputs(TIM1, ENABLE); //主输出使能，当使用的是通用定时器时，这句不需要
	
	//E 8~15 方向控制
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE,ENABLE);
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = 0xff00;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOE, &GPIO_InitStructure);
}

//0 1
//2 3
//同时设置ccr（占空值数）int*
void PWM_set(int8_t speed1, int8_t speed0, int8_t speed3, int8_t speed2){
	uint16_t fang[4][2] = {
		{ GPIO_Pin_8, GPIO_Pin_9 },
		{ GPIO_Pin_10, GPIO_Pin_11 },
		{ GPIO_Pin_12, GPIO_Pin_13 },
		{ GPIO_Pin_14, GPIO_Pin_15 }
	};
	int8_t speed[4] = { speed0, speed1, speed2, speed3 };
	
	for(int i = 0; i < 4; i++){
		if(speed[i] >= 0){
			GPIO_ResetBits(GPIOE, fang[i][1]);
			GPIO_SetBits(GPIOE, fang[i][0]);
		}
		else{
			GPIO_ResetBits(GPIOE, fang[i][0]);
			GPIO_SetBits(GPIOE, fang[i][1]);
		}
		TIM_SetCompare1(TIM1, (uint16_t)abs((int)speed[0]));
		TIM_SetCompare2(TIM1, (uint16_t)abs((int)speed[1]));
		TIM_SetCompare3(TIM1, (uint16_t)abs((int)speed[2]));
		TIM_SetCompare4(TIM1, (uint16_t)abs((int)speed[3]));
	}
	
}

void PWM_Con(int8_t speed , uint8_t x){
	uint16_t fang[4][2] = {
		{ GPIO_Pin_8, GPIO_Pin_9 },
		{ GPIO_Pin_10, GPIO_Pin_11 },
		{ GPIO_Pin_12, GPIO_Pin_13 },
		{ GPIO_Pin_14, GPIO_Pin_15 }
	};
	
	if(speed >= 0){
			GPIO_ResetBits(GPIOE, fang[x][1]);
			GPIO_SetBits(GPIOE, fang[x][0]);
		}
		else{
			GPIO_ResetBits(GPIOE, fang[x][0]);
			GPIO_SetBits(GPIOE, fang[x][1]);
		}
	if(x == 1)TIM_SetCompare1(TIM1, (uint16_t)abs((int)speed));
	if(x == 2)TIM_SetCompare2(TIM1, (uint16_t)abs((int)speed));
	if(x == 3)TIM_SetCompare3(TIM1, (uint16_t)abs((int)speed));
	if(x == 4)TIM_SetCompare4(TIM1, (uint16_t)abs((int)speed));
}
