#ifndef __HALL_H__
#define __HALL_H__


void Hall_Init(void);
int16_t Hall_back(int8_t num);
void Hall_Cmd(FunctionalState NewState);

#endif

