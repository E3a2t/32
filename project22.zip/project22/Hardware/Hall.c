#include "stm32f10x.h"                  // Device header


//a 0 1 6 7 
//b 6 7 
//c 6 7

void Hall_Init(void){	
	
	
	//��ʼ�򿪲���
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM8, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5, ENABLE);
	
	
	
	GPIO_InitTypeDef GPIO_Initstructure;
	GPIO_Initstructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Initstructure.GPIO_Pin = 0x00C3;
	GPIO_Initstructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_Initstructure);
	
	GPIO_Initstructure.GPIO_Pin = 0x00C0;
	GPIO_Init(GPIOB, &GPIO_Initstructure);
	GPIO_Init(GPIOC, &GPIO_Initstructure);
	
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStructure.TIM_Period = 0xFFFF;			//ARR max:65535
	TIM_TimeBaseInitStructure.TIM_Prescaler = 1 - 1;		//PSC ����Ƶ
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
	
	TIM_TimeBaseInit(TIM8, &TIM_TimeBaseInitStructure);
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseInitStructure);
	TIM_TimeBaseInit(TIM4, &TIM_TimeBaseInitStructure);
	TIM_TimeBaseInit(TIM5, &TIM_TimeBaseInitStructure);
	
	TIM_ICInitTypeDef TIM_ICInitStructure;
	TIM_ICStructInit(&TIM_ICInitStructure);
	
	TIM_ICInitStructure.TIM_Channel = TIM_Channel_1;
	TIM_ICInitStructure.TIM_ICFilter = 0xF;

	TIM_ICInit(TIM8, &TIM_ICInitStructure);
	TIM_ICInit(TIM3, &TIM_ICInitStructure);
	TIM_ICInit(TIM4, &TIM_ICInitStructure);
	TIM_ICInit(TIM5, &TIM_ICInitStructure);
	
	TIM_ICInitStructure.TIM_Channel = TIM_Channel_2;
	
	TIM_ICInit(TIM8, &TIM_ICInitStructure);
	TIM_ICInit(TIM3, &TIM_ICInitStructure);
	TIM_ICInit(TIM4, &TIM_ICInitStructure);
	TIM_ICInit(TIM5, &TIM_ICInitStructure);
	

	TIM_EncoderInterfaceConfig(TIM8, TIM_EncoderMode_TI12, TIM_ICPolarity_Rising, TIM_ICPolarity_Rising);
	TIM_EncoderInterfaceConfig(TIM3, TIM_EncoderMode_TI12, TIM_ICPolarity_Rising, TIM_ICPolarity_Rising);
	TIM_EncoderInterfaceConfig(TIM4, TIM_EncoderMode_TI12, TIM_ICPolarity_Rising, TIM_ICPolarity_Rising);
	TIM_EncoderInterfaceConfig(TIM5, TIM_EncoderMode_TI12, TIM_ICPolarity_Rising, TIM_ICPolarity_Rising);
	

	//TIM_Cmd(TIM8, ENABLE);
	//TIM_Cmd(TIM3, ENABLE);
	//TIM_Cmd(TIM4, ENABLE);
	//TIM_Cmd(TIM5, ENABLE);
}

void Hall_Cmd(FunctionalState NewState){
	TIM_Cmd(TIM8, NewState);
	TIM_Cmd(TIM3, NewState);
	TIM_Cmd(TIM4, NewState);
	TIM_Cmd(TIM5, NewState);
	
	TIM_SetCounter(TIM8, 0);
	TIM_SetCounter(TIM3, 0);
	TIM_SetCounter(TIM4, 0);
	TIM_SetCounter(TIM5, 0);
}

// TIM8: C6 C7
// TIM3: A6 A7
// TIM4: B6 B7
// TIM5: A0 A1
int16_t Hall_back(int8_t num){
	TIM_TypeDef * tims[4] = { TIM8, TIM3, TIM4, TIM5 };

	int16_t back = (int16_t)TIM_GetCounter(tims[num]);
	TIM_SetCounter(tims[num], 0);
	return back;
}

