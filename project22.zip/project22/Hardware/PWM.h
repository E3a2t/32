#ifndef __PWM_H__
#define __PWM_H__



void PWM_Init(void);
void PWM_set(int8_t speed0, int8_t speed1, int8_t speed2, int8_t speed3);
void PWM_Con(int8_t speed , uint8_t x);

#endif
