#include "stm32f10x.h"                  // Device header
#include "PWM.h"
#include "Delay.h"
#include "Hall.h"


// error: 0~ 127

uint16_t set[4];
uint16_t __set__=20;

// 0 ~ 63
int8_t* PID_change(int8_t error){
	static float back_f[2] = { 0 }; // ???
	static int8_t back[2] = { 0 };
	static float p_ = 0.57, i_ = 0, d_ = 0.05; // pid
	//error -= 64;

	float num0 = 60;
	back_f[0] = num0;
	back_f[1] = num0;

	// p
	back_f[0] += error * p_;			//??
	back_f[1] += (127 - error) * p_;	//??

	// i
	static float add = 0;
	add += error;
	back_f[0] += add * i_;
	back_f[1] -= add * i_;

	//d
	static int8_t last = 0;
	back_f[0] += (error - last) * d_;
	back_f[0] -= (error - last) * d_;
	last = error;

	// return
	back[0] = back_f[0];
	back[1] = back_f[1];

	return back;
}


void goon(void){ 
	/*
	uint16_t hall[4]={0};
	PWM_set(100, 100, 100, 100);
	while(1){ 
		hall += back()
		if hall > __set__:
			PWM_set(0)
	}
	
	Delay_s(2);
	PWM_set(0, 0, 0, 0);
	*/
}

void right(void){
	/*
	uint16_t hall[4]={0};
	set[0]=100,set[1]=-100,set[2]=100,set[3]=-100;
	PWM_set(set[0], set[1], set[2], set[3]);
	while(1){
		for(int i=0;i<4;i++){
			hall[i] += Hall_back(i);
			if (hall[i] > __set__ ){
				set[i]=0;
				PWM_Con(0,i);
			}
		}
		if(set[0]==0&&set[1]==0&&set[2]==0&&set[3]==0)
			break;
	}
	*/
}

void left(void){
	/*
	uint16_t hall[4]={0};
	set[0]=-100,set[1]=100,set[2]=-100,set[3]=100;
	PWM_set(set[0], set[1], set[2], set[3]);
	while(1){
		for(int i=0;i<4;i++){
			hall[i] += Hall_back(i);
			if (hall[i] > __set__ )
				set[i]=0;
				PWM_Con(0,i);
		}
		if(set[0]==0&&set[1]==0&&set[2]==0&&set[3]==0)
			break;
	}
	*/
}

void T_back(void){
	/*
	uint16_t hall[4]={0};
	set[0]=100,set[1]=-100,set[2]=100,set[3]=-100;
	PWM_set(set[0], set[1], set[2], set[3]);
	while(1){
		for(int i=0;i<4;i++){
			hall[i] += Hall_back(i);
		if (hall[i] > __set__ )
			set[i]=0;
			PWM_Con(0,i);
		}
		if(set[0]==0&&set[1]==0&&set[2]==0&&set[3]==0)
			break;
	}
	*/
}


