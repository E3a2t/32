#ifndef __con_h__
#define __con_h__


int8_t* PID_change(int8_t error);
void goon(void);
void right(void);
void left(void);
void T_back(void);
        
#endif
